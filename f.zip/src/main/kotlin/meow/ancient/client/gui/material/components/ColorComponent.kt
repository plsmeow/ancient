package meow.ancient.client.gui.material.components

import meow.ancient.client.extensions.mc
import meow.ancient.client.gui.material.AnimFloat
import meow.ancient.client.gui.material.ClickGuiScreen
import meow.ancient.client.gui.material.M3Theme
import meow.ancient.client.util.render.RenderUtils
import meow.ancient.client.util.render.engine.controls.ClientRenderPipeline
import meow.ancient.client.util.render.font.Fonts
import meow.ancient.module.setting.ColorSetting
import org.joml.Matrix4f

class ColorComponent(private val colorSetting: ColorSetting) : SettingComponent(colorSetting) {
    private val hoverAnim = AnimFloat(0f, 0f, 14f)

    override fun render(
        matrix: Matrix4f,
        x: Float,
        y: Float,
        width: Float,
        mouseX: Int,
        mouseY: Int,
        dt: Float
    ): Float {
        this.x = x
        this.y = y
        this.width = width
        this.height = 20f

        val palette = M3Theme.current
        val hovered = isHovered(mouseX.toDouble(), mouseY.toDouble(), x, y, width, height)
        val hoverAlpha = hoverAnim.update(if (hovered) 1f else 0f, dt)

        if (hoverAlpha > 0.01f) {
            RenderUtils.roundedRect(
                matrix = matrix,
                x = x + 2f,
                y = y + 1f,
                width = width - 4f,
                height = height - 2f,
                color = palette.stateHover.alpha((palette.stateHover.a * hoverAlpha).toInt()),
                radius = 4f,
                pipeline = ClientRenderPipeline.WINDOW_RECT
            )
        }

        val swatchW = 24f
        val swatchH = 12f
        val swatchX = x + width - swatchW - 4f
        val swatchY = y + (height - swatchH) * 0.5f

        val maxTextW = swatchX - (x + 4f) - 4f
        val fitted = fitText(colorSetting.name, maxTextW, baseSize = 10f, minSize = 8f)

        Fonts.google_sans_regular.drawString(
            matrix = matrix,
            text = fitted.text,
            x = x + 4f,
            y = y + (height - fitted.size) * 0.5f - 1f,
            size = fitted.size,
            color = palette.onSurface,
            shadow = false,
            pipeline = ClientRenderPipeline.WINDOW_TEXT
        )

        RenderUtils.roundedRect(
            matrix = matrix,
            x = swatchX,
            y = swatchY,
            width = swatchW,
            height = swatchH,
            color = colorSetting.value,
            radius = 3f,
            pipeline = ClientRenderPipeline.WINDOW_RECT
        )

        return height
    }

    override fun mouseClicked(mouseX: Double, mouseY: Double, button: Int): Boolean {
        if (button == 0 && isHovered(mouseX, mouseY, x, y, width, height)) {
            if (ClickGuiScreen.activeColorPicker?.setting == colorSetting) {
                ClickGuiScreen.activeColorPicker = null
            } else {
                val picker = ColorPickerWindow(
                    setting = colorSetting,
                    x = 0f,
                    y = 0f
                )
                var winX = x + width + 8f
                if (winX + picker.width > mc.window.guiScaledWidth - 10f) {
                    winX = x - picker.width - 8f
                }
                if (winX < 10f) {
                    winX = ((mc.window.guiScaledWidth - picker.width) * 0.5f).coerceAtLeast(10f)
                }
                val winY = y.coerceIn(10f, (mc.window.guiScaledHeight - picker.height - 10f).coerceAtLeast(10f))
                picker.x = winX
                picker.y = winY

                ClickGuiScreen.activeColorPicker = picker
            }
            return true
        }
        return false
    }
}
