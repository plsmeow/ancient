package meow.ancient.module

import com.mojang.blaze3d.platform.InputConstants
import meow.ancient.client.extensions.Category
import meow.ancient.client.extensions.SafeClientContext
import meow.ancient.client.interfaces.IToggable
import meow.ancient.client.gui.hud.HudNotificationCenter
import meow.ancient.client.util.other.color.Color4b
import meow.ancient.event.EventManager
import meow.ancient.module.setting.*

open class Module(
    val name: String,
    val category: Category,
    val description: String = "",
    var key: Int = InputConstants.UNKNOWN.value
) : IToggable {
    private var enabled = false
    private var toggleDepth = 0
    var state: Boolean
        get() = enabled
        set(value) = setEnabled(value)
    var isExpanded = false
    val settings: MutableList<Setting<*>> = ArrayList()

    override fun isEnabled(): Boolean {
        return enabled
    }

    override fun setEnabled(value: Boolean) {
        if (value == enabled) return

        val previousState = enabled
        val outermost = toggleDepth++ == 0
        try {
            enabled = value
            if (value) {
                superEnable()
                onEnable()
            } else {
                superDisable()
                onDisable()
            }
        } finally {
            toggleDepth--
        }
        if (outermost && enabled != previousState) {
            HudNotificationCenter.moduleToggled(name, enabled)
        }
    }

    override fun toggle() {
        setEnabled(!enabled)
    }

    private fun superDisable() {
        EventManager.unregister(this)
    }

    private fun superEnable() {
        EventManager.register(this)
    }

    open fun onDisable() {}
    open fun onEnable() {}

    inline fun <R> safeRun(block: SafeClientContext.() -> R): R? =
        meow.ancient.client.extensions.safeRun(block)

    fun <T : Setting<*>> register(setting: T): T {
        if (!settings.contains(setting)) {
            settings.add(setting)
        }
        return setting
    }

    fun text(
        name: String,
        value: String,
        maxLength: Int = 256,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(TextSetting(name, value, maxLength, description, isVisible))

    fun <T> picker(
        name: String,
        value: Set<String>,
        catalog: PickerCatalog<T>,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(PickerSetting(name, value, catalog, description, isVisible))

    fun boolean(
        name: String,
        value: Boolean,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(BooleanSetting(name, value, description, isVisible))

    fun booleanSetting(
        name: String,
        value: Boolean,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = boolean(name, value, description, isVisible)

    fun number(
        name: String,
        value: Double,
        min: Double,
        max: Double,
        step: Double = 0.1,
        precision: Int = 1,
        unit: String = "",
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(NumberSetting(name, value, min, max, step, precision, unit, description, isVisible))

    fun numberSetting(
        name: String,
        value: Double,
        min: Double,
        max: Double,
        step: Double = 0.1,
        precision: Int = 1,
        unit: String = "",
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = number(name, value, min, max, step, precision, unit, description, isVisible)

    inline fun <reified E : Enum<E>> enum(
        name: String,
        defaultValue: E,
        description: String = "",
        noinline nameMapper: (E) -> String = { it.name },
        noinline isVisible: () -> Boolean = { true }
    ): EnumSetting<E> = register(
        EnumSetting(name, defaultValue, enumValues<E>(), description, nameMapper, isVisible)
    )

    inline fun <reified E : Enum<E>> enumSetting(
        name: String,
        defaultValue: E,
        description: String = "",
        noinline nameMapper: (E) -> String = { it.name },
        noinline isVisible: () -> Boolean = { true }
    ): EnumSetting<E> = enum(name, defaultValue, description, nameMapper, isVisible)

    fun mode(
        name: String,
        value: String,
        modes: List<String>,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(ModeSetting(name, value, modes, description, isVisible))

    fun modeSetting(
        name: String,
        value: String,
        modes: List<String>,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = mode(name, value, modes, description, isVisible)

    fun multiMode(
        name: String,
        value: Set<String>,
        modes: List<String>,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(MultiModeSetting(name, value, modes, description, isVisible))

    fun multiModeSetting(
        name: String,
        value: Set<String>,
        modes: List<String>,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = multiMode(name, value, modes, description, isVisible)

    fun color(
        name: String,
        value: Color4b,
        hasAlpha: Boolean = true,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(ColorSetting(name, value, hasAlpha, description, isVisible))

    fun colorSetting(
        name: String,
        value: Color4b,
        hasAlpha: Boolean = true,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = color(name, value, hasAlpha, description, isVisible)

    fun color(
        name: String,
        r: Int,
        g: Int,
        b: Int,
        a: Int = 255,
        hasAlpha: Boolean = true,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(ColorSetting(name, r, g, b, a, hasAlpha, description, isVisible))

    fun colorPicker(
        name: String,
        value: Color4b,
        hasAlpha: Boolean = true,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = color(name, value, hasAlpha, description, isVisible)

    fun colorPicker(
        name: String,
        r: Int,
        g: Int,
        b: Int,
        a: Int = 255,
        hasAlpha: Boolean = true,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = color(name, r, g, b, a, hasAlpha, description, isVisible)

    fun keybind(
        name: String,
        value: Int = InputConstants.UNKNOWN.value,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = register(KeybindSetting(name, value, description, isVisible))

    fun keybindSetting(
        name: String,
        value: Int = InputConstants.UNKNOWN.value,
        description: String = "",
        isVisible: () -> Boolean = { true }
    ) = keybind(name, value, description, isVisible)
}
