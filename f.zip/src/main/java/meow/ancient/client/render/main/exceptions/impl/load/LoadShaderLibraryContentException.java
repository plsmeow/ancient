package meow.ancient.client.render.main.exceptions.impl.load;

import meow.ancient.client.render.main.exceptions.ChromaException;

public class LoadShaderLibraryContentException extends ChromaException {
    @java.io.Serial
    private static final long serialVersionUID = -6809337209489732866L;

    public LoadShaderLibraryContentException(Exception e) {
        super(
                "Load library content error.",
                "Cannot load library content. Reason:\n".concat(e.getMessage()),
                new String[]{
                        "Error in content loader",
                        "Inability to access content",
                        "Another error"
                },
                new String[]{
                        "Make sure your content loader is working properly (if you are using a custom loader)",
                        "Make sure you store or have access to the library content",
                        "Check out the details"
                }
        );
    }
}
